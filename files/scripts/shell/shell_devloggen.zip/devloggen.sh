#!/bin/sh
LOGDATE=$(date +%F)

echo Development Log >> devlog_"$LOGDATE".txt
echo "$LOGDATE" >> devlog_"$LOGDATE".txt
echo --------------- >> devlog_"$LOGDATE".txt
