The F*ck It Button is a weapon mod for GZDoom 4.5+ that replaces the BFG
with a new, arguably more devastating weapon. That weapon is, of course,
known as the F*ck It Button.

When you press the F*ck It Button, it will produce a rapid series of 12
explosions that deal 9,999 damage to everything within a 5,000mu radius.
In the case of the stock monsters in Doom, this of course means that it
instakills all of them, even Cyberdemons and Spider Masterminds.

KNOWN ISSUES:
- Each explosion will only work on a single Cyberdemon and/or Spider
  Mastermind at a time.
- The button has a chance to stop working on Cyberdemons and Spider
  Masterminds under certain circumstances. I have yet to pinpoint what
  those circumstances are.